package modelo;

import java.util.Date;

public class Historia {

    private Paciente paciente;

    private Date fecha;

    private String descripcion;

    private Medico medico;
}
