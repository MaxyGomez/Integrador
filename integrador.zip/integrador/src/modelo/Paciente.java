package modelo;

import java.util.List;

public class Paciente extends Persona {

    private String historial;
    private List<Historia> historiaClinica;
    private List<Cita> listaCitas;

    public Paciente() {
    }
    public void setNombres (String nombre){
        super.setNombres(nombre);
    }
            
    
}
