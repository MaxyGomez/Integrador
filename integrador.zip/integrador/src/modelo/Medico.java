package modelo;

import java.util.List;

public class Medico extends Persona {

    private String numeroMatricula;

    private String especialidad;

    private List<Turno> turno;
}
