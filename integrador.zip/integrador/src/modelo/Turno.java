package modelo;

import java.util.Date;
import java.util.List;

public class Turno {

    private Medico medico;

    private String nombre;

    private List<Cita> citas;

    private Date fecha;
}
