package modelo;

import java.util.List;

public class Administrativo extends Persona {

    private List<Cita> recordatorio;
}
