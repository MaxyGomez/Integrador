package modelo;

import java.util.Date;

public class Cita {

    private Paciente paciente;

    private Medico medico;

    private Date horaComienzo;

    private Date horaTermina;

    private boolean disponible;
}
